
'use strict';
/* ═══════════════════════════════════════════════════════════════
   银河系中心酒吧 · 单文件调酒经营小游戏
   纯 CSS + SVG + JS 实现（未使用SVG，全部CSS），无任何外部依赖
   ═══════════════════════════════════════════════════════════════ */

/* ════════════ 一、配置区（配方/数值/文案全部集中在这里，方便迭代） ════════════ */
const CONFIG = {
  START_REP: 50,           // 初始声望
  MAX_QUEUE: 4,            // 场上最多同时存在的顾客数量（3-4位），满员后新顾客直接流失
  MAX_LOST: 20,            // 流失顾客达到该数量 → GameOver
  SHAKER_CAPACITY: 4,      // 调酒壶最多装 4 份原料（冰块不计入）
  SHAKE_CLICK_GAIN: 40,    // 每次点击调酒壶 / 按空格增加的进度（%）——摇 2 下 80%，第 3 下必满
  SHAKE_AUTO_RATE: 4,      // 自动摇酒：每个心跳（100ms）增加的进度（%）
  SHAKE_CLICK_COOLDOWN: 130, // 点击/空格摇酒的冷却（毫秒）
  DAY_SECONDS: 90,         // 每 N 秒进入下一天（难度递增）
  SPAWN_BASE: 13,          // 初始刷客间隔（秒）：刚开业客人流量稍多一点
  SPAWN_MIN: 6,            // 刷客间隔下限（秒）
  SPAWN_RAMP: 1.5,         // 从第 5 天起，每过一天刷客间隔缩短的秒数（慢慢加快）
  PATIENCE_BASE: 60,       // 单客基础耐心（秒）：一位客人 60s 正常
  PATIENCE_QUEUE_BONUS: 8, // 排队等待的人多时，每位等待者增加的耐心（秒）
  PATIENCE_QUEUE_BONUS_CAP: 24, // 排队加时上限（秒）
  LOST_PENALTY_COINS: 15,  // 流失顾客扣星币
  LOST_PENALTY_REP: 5,     // 流失顾客扣声望
  GRADES: {                // 评分分级 → 星币倍率 + 声望变化
    perfect: { label: '完美', mult: 1.0, rep: 10 },
    good:    { label: '良好', mult: 0.7, rep: 5 },
    bad:     { label: '差评', mult: 0.4, rep: -5 },
    fail:    { label: '失败', mult: 0.1, rep: -10 },
  },
};

/* ════════════ 内嵌素材（包内文件） ════════════ */
const STORY_BG1 = 'images/story-bg1.jpg'; // 幕1：银河系中心酒吧外观

const STORY_CHAR1 = 'images/story-char1.png'; // 幕1：小水手（透明底） // 幕1：小水手

const STORY_BG2 = 'images/story-bg2.jpg'; // 幕2：酒吧内景（场景2）

const STORY_CHAR2 = 'images/story-char2.png'; // 幕2：烬行（透明底） // 幕2：烬行 // 幕2：烬行


/* 背景图配置：
   实拍吧台图（images/bar-bg.jpg）。如需更换/移除：
   · 移除照片 → 改为 const BG_IMAGE = '';（回退到 CSS 星空背景）
   · 换外部图片 → const BG_IMAGE = 'url(你的图片.jpg)'; 并与本文件放同一目录 */
const BG_IMAGE = 'images/bar-bg.jpg';

/* 全部原料（颜色用于酒液配色渲染） */
const INGREDIENTS = [
  // 基底酒
  { id: 'vodka',    name: '伏特加',   cat: 'spirit',  color: '#eef7fb' },
  { id: 'tequila',  name: '龙舌兰',   cat: 'spirit',  color: '#f7e8c9' },
  { id: 'rum',      name: '朗姆酒',   cat: 'spirit',  color: '#d9a765' },
  { id: 'gin',      name: '金酒',     cat: 'spirit',  color: '#e2f5e0' },
  { id: 'whisky',   name: '威士忌',   cat: 'spirit',  color: '#c1843f' },
  // 利口酒
  { id: 'triplesec', name: '橙味利口酒', cat: 'liqueur', color: '#f5a83c' },
  { id: 'bluecuracao', name: '蓝橙酒', cat: 'liqueur', color: '#2f6fd8' },
  { id: 'kahlua',   name: '咖啡利口酒', cat: 'liqueur', color: '#5b3a24' },
  { id: 'midori',   name: '蜜瓜利口酒', cat: 'liqueur', color: '#8fd84e' },
  { id: 'vermouth', name: '干味美思', cat: 'liqueur', color: '#d8c39a' },
  { id: 'chartreuse', name: '查特酒',  cat: 'liqueur', color: '#8fbf2f' },
  { id: 'violetcream', name: '紫罗兰利口酒', cat: 'liqueur', color: '#a878ff' },
  { id: 'tokaji',   name: '托卡伊甜酒', cat: 'liqueur', color: '#e6b93f' },
  // 果汁
  { id: 'lime',     name: '青柠汁',   cat: 'juice',   color: '#cfe86a' },
  { id: 'lemon',    name: '柠檬汁',   cat: 'juice',   color: '#f5e97a' },
  { id: 'orange',   name: '橙汁',     cat: 'juice',   color: '#ffab3c' },
  { id: 'cranberry', name: '蔓越莓汁', cat: 'juice',  color: '#d84e6a' },
  { id: 'pineapple', name: '菠萝汁',  cat: 'juice',   color: '#f7d66a' },
  { id: 'strawberry', name: '草莓汁', cat: 'juice',   color: '#ff7b9c' },
  // 配料（液体辅料，原料架「配料」页签）
  { id: 'syrup',    name: '糖浆',     cat: 'mixer',   color: '#eecf96' },
  { id: 'soda',     name: '苏打水',   cat: 'mixer',   color: '#eaf6f8' },
  { id: 'cream',    name: '奶油',     cat: 'mixer',   color: '#f7f0e2' },
  { id: 'cola',     name: '可乐',     cat: 'mixer',   color: '#6b4423' },
  { id: 'milk',     name: '牛奶',     cat: 'mixer',   color: '#fdf3e3' },
  // 小料（装饰物/点缀，原料架「小料」页签）
  { id: 'orange_peel',  name: '橙皮',     cat: 'garnish', color: '#f59b2c' },
  { id: 'brandied_cherry', name: '酒渍黑樱桃', cat: 'garnish', color: '#6e1f3a' },
  { id: 'cinnamon_stick', name: '肉桂棒',  cat: 'garnish', color: '#9c6b3f' },
  { id: 'sugar_rim',  name: '红糖霜杯边', cat: 'garnish', color: '#b06a3a' },
  { id: 'angostura',  name: '安格斯特拉芳香苦精', cat: 'garnish', color: '#8c3b1f' },
  { id: 'gold_powder', name: '可食用闪金粉', cat: 'garnish', color: '#e9c96a' },
];

/* 水果装饰（乱给水果会扣分，不给不能上酒） */
const FRUITS = [
  { id: 'lime_w',     name: '青柠片', emoji: '🍋', bg: '#7fb63f' },
  { id: 'lemon_w',    name: '柠檬片', emoji: '🍋', bg: '#f2d24a' },
  { id: 'orange_w',   name: '橙片',   emoji: '🍊', bg: '#f59b2c' },
  { id: 'cherry',     name: '樱桃',   emoji: '🍒', bg: '#e04a6a' },
  { id: 'pineapple_w', name: '菠萝角', emoji: '🍍', bg: '#f0c03c' },
  { id: 'strawberry_w', name: '草莓', emoji: '🍓', bg: '#ff5d7a' },
];

/* 顾客角色头像（180px 内嵌） */
const CHAR_IMG = {
  jinxing: 'images/av-jinxing.png',
  linf: 'images/av-linf.png',
  duyi: 'images/av-duyi.png',
  talas: 'images/av-talas.png',
  sword: 'images/av-sword.png',
  cybern: 'images/av-cybern.png',
  chan: 'images/av-chan.png',
  shrimp: 'images/av-shrimp.png',
};






/* 鸡尾酒配方表（新增酒品只需加一行；owner = 「XX 的配方」署名彩蛋）
   每款酒都由 原料 + 配料 + 小料 + 水果 搭配调配，客人会随机点到全部酒款 */
const RECIPES = [
  { id: 'strawberry_rum', name: '草莓朗姆酒', owner: '烬行的配方', color: '#ff8ab0', diff: 1, needsShake: true,  ingredients: ['rum', 'strawberry', 'lime', 'sugar_rim'],          fruit: 'strawberry_w', reward: 55 },
  { id: 'blue_margarita', name: '蓝色玛格丽特', owner: '铃弗瑞迪尔的配方', color: '#2f6fd8', diff: 3, needsShake: true, ingredients: ['tequila', 'bluecuracao', 'lime', 'sugar_rim'],  fruit: 'lime_w',        reward: 120 },
  { id: 'chartreuse_green', name: '查特绿', owner: '度漪的配方', color: '#8fbf2f', diff: 2, needsShake: false, ingredients: ['chartreuse', 'lime', 'soda', 'cinnamon_stick'],      fruit: 'lime_w',        reward: 80 },
  { id: 'violet_cream',   name: '紫罗兰奶油利口酒', owner: '塔拉撒里昂的配方', color: '#a878ff', diff: 2, needsShake: true, ingredients: ['violetcream', 'cream', 'syrup', 'gold_powder'], fruit: 'cherry',         reward: 90 },
  { id: 'tokaji_asu',     name: '托卡伊阿苏', owner: '赛博恩的配方', color: '#e6b93f', diff: 2, needsShake: false, ingredients: ['tokaji', 'lemon', 'orange_peel', 'cinnamon_stick'], fruit: 'lemon_w',        reward: 75 },
  { id: 'vodka_pure',     name: '伏特加', owner: '斯沃德麦伦的配方', color: '#f2f4f6', diff: 1, needsShake: false, ingredients: ['vodka', 'orange_peel', 'angostura'],               fruit: 'orange_w',       reward: 45 },
  { id: 'iced_cola',      name: '冰镇可乐', owner: '谶的配方', color: '#6b4423', diff: 1, needsShake: false, ingredients: ['cola', 'lemon', 'brandied_cherry', 'angostura'],       fruit: 'lemon_w',        reward: 40 },
  { id: 'grass_milk',     name: '草泡奶', owner: '神秘配方', color: '#ff4d6a', diff: 1, needsShake: true,  ingredients: ['strawberry', 'milk', 'syrup', 'gold_powder'],        fruit: 'strawberry_w',  reward: 60 },
];

/* 星际旅客的随机头像（趣味身份 emoji 池） */
const RACES = [
  { avatar: '🧑‍🚀' }, { avatar: '👽' }, { avatar: '🤖' }, { avatar: '🦾' },
  { avatar: '😺' }, { avatar: '🦑' }, { avatar: '💎' }, { avatar: '🏴‍☠️' },
  { avatar: '⏳' }, { avatar: '👑' },
];

/* ════════ 顾客角色 ════════
   固定角色带专属头像 + 头顶气泡台词（出场时冒出，与订单无关）
   · 斯沃德麦伦：未成年 → 固定订单=冰镇可乐，从下往上出场
   · 赛博恩：固定订单=伏特加（十万伏特）  · 谶：固定订单=草泡奶
   · 无可奉告：黑色方块，订单页只显示「无可奉告」，随便给什么都行 */
const CHARACTERS = [
  { id: 'jinxing', name: '烬行',       img: CHAR_IMG.jinxing, race: '赛博人',   quote: '我只是一名普普通通的调酒师', fixedOrder: null },
  { id: 'linf',    name: '铃弗瑞迪尔', img: CHAR_IMG.linf,    race: '人鱼族',   quote: '辛苦了，要好好休息哦',       fixedOrder: null },
  { id: 'duyi',    name: '度漪',       img: CHAR_IMG.duyi,    race: '精灵族',   quote: '可以给我你的半点心吗',       fixedOrder: null },
  { id: 'talas',   name: '塔拉撒里昂', img: CHAR_IMG.talas,   race: '龙裔',     quote: '喂，本王渴了',               fixedOrder: null },
  { id: 'sword',   name: '斯沃德麦伦', img: CHAR_IMG.sword,   race: '猫耳族',   quote: '嘿嘿嘿',                     fixedOrder: 'iced_cola', entrance: 'up' },
  { id: 'cybern',  name: '赛博恩',     img: CHAR_IMG.cybern,  race: '机器人',   quote: '本大爷要十万伏特',           fixedOrder: 'vodka_pure' },
  { id: 'chan',    name: '谶',         img: CHAR_IMG.chan,    race: '幽灵族',   quote: '请给本大侠一杯草泡奶',       fixedOrder: 'grass_milk' },
  { id: 'shrimp',  name: '虾兵蟹将的将', img: CHAR_IMG.shrimp, race: '海族',    quote: '咔咔咔',                    fixedOrder: null },
  { id: 'unknown', name: '无可奉告',   img: null,             race: '未知',     quote: '无可奉告',                   mystery: true },
];

/* 星际旅客的随机种族池 */
const COMMON_RACES = ['人鱼族', '赛博人', '地球人', '火星人', '机器人', '精灵族', '猫耳星人', '触手星人', '水晶星人', '时间旅人', '星际海盗', '仙女座贵族', '龙裔', '幽灵族'];

/* 星际旅客（普通顾客）：主力客源，随机名字 + 五字以内短气泡（可为空）+ 随机订单 */
const COMMON_NAMES = ['阿伟', '小美', '老王', '丽丽', '大壮', '阿珍', '小K', '老陈', 'Nova', 'Luna', 'Kira', 'Zed', '团团', '阿星', '拾月', '小满', '阿七', '灰灰', '晚风', '青柠'];
const COMMON_QUOTES = ['你好呀', '来一杯', '渴了', '夜安', '随便吧', '推荐一下', '快点哦', '谢谢啦', '久仰', '今晚月色真美', '嗯', '哦', ''];

/* 顾客结算/离场台词库 */
const DIALOGUE = {
  perfect: ['太棒了！五星好评！', '银河系第一的调酒师！', '完美！下次还来！', '这味道，简直星尘级！'],
  good: ['不错不错，再接再厉！', '还可以，给个好评吧！', '味道还行，下次再来！'],
  bad: ['就这？我要在星网给你差评！', '味道不太对啊老板……', '一般般，失望！'],
  fail: ['太难喝了！差评差评！', '这是什么黑暗料理！', '呸呸呸！再也不来了！'],
  timeout: ['等太久了，走了！', '本星人的耐心是有限的！', '不喝了！浪费时间！'],
  overflow: ['这么多人？不排了！', '排队太长了，走人！'],
};


/* ════════════ 一·五、开场剧情对话（首次加载自动播放，刷新重播） ════════════
   三幕结构：幕1 酒吧外观+小水手 → 幕2 暗屏切换+烬行 → 幕3 进入游戏。
   bg/char 传 null 表示沿用上一段的场景与角色。 */
const STORY = [
  { scene: 1, bg: STORY_BG1,   char: STORY_CHAR1, name: '小水手', text: '检测到碳基生物......欢迎......欢迎！' },
  { scene: 2, bg: STORY_BG2,   char: STORY_CHAR2, name: '烬行',   text: '你好，我是酒吧的老板，烬行。' },
  { scene: 2, bg: null, char: null, name: '烬行', text: '走进酒吧我们就是彼此的同行者。' },
  { scene: 2, bg: null, char: null, name: '烬行', text: '在这里，只是相遇，只是存在，只是举杯。' },
  { scene: 2, bg: null, char: null, name: '烬行', text: '（说了一些赞美的话）那就这么说定了，你守护酒吧，我们守护你，干杯！' },
  { scene: 2, bg: null, char: null, name: '烬行', text: '拍完了，赛博恩' },
  { scene: 2, bg: null, char: null, name: '烬行', text: '关一下机，赛博恩' },
  { scene: 2, bg: null, char: null, name: '烬行', text: '赛博恩' },
];

let storyIdx = -1, storyTypeTimer = null, storyBusy = false, storyBg = '';

/* 把一句话按标点切成小段（。！？，和省略号处断开），逐段浮现，放慢对话节奏 */
function splitSegs(text) {
  const segs = [];
  let cur = '';
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    cur += ch;
    const isEllipsisEnd = ch === '.' && i >= 2 && text.slice(i - 2, i + 1) === '...'
      && (i + 1 >= text.length || text[i + 1] !== '.');
    if ('。！？，'.includes(ch) || isEllipsisEnd) { segs.push(cur); cur = ''; }
  }
  if (cur) segs.push(cur);
  return segs;
}

/* 打字机逐字出现：每段之间停顿片刻，节奏放缓（点击可跳过直接显示完整句子） */
function startStoryType(s) {
  const t = el('story-text');
  el('story-name').textContent = s.name;
  el('story-hint').style.opacity = 0;
  t.textContent = '';
  const segs = splitSegs(s.text);
  let si = 0, ci = 0;
  const step = () => {
    ci++;
    t.textContent = segs.slice(0, si).join('') + segs[si].slice(0, ci);
    if (ci % 3 === 0 && state.soundOn && actx) playSound('tick');
    if (ci >= segs[si].length) {
      si++;
      if (si >= segs.length) { finishStoryType(); return; }
      ci = 0;
      storyTypeTimer = setTimeout(step, 560);   // 分段间停顿
    } else {
      storyTypeTimer = setTimeout(step, 72);    // 逐字间隔（放缓）
    }
  };
  storyTypeTimer = setTimeout(step, 420);
}
function finishStoryType() {
  if (storyTypeTimer) { clearTimeout(storyTypeTimer); storyTypeTimer = null; }
  const s = STORY[storyIdx];
  if (s) {
    el('story-text').textContent = s.text;
    el('story-hint').style.opacity = 1;
  }
}

/* 下一段对话：换场景时暗屏切换背景与角色（背景未变则不转场） */
function nextStoryLine() {
  storyIdx++;
  if (storyIdx >= STORY.length) { endStory(); return; }
  const s = STORY[storyIdx];
  if (s.bg && s.bg !== storyBg) {
    storyBusy = true;
    storyBg = s.bg;
    el('story-blackout').classList.add('on');
    setTimeout(() => {
      if (!state.storyActive) return;   // 被跳过：不再操作已关闭的遮罩
      el('story-bg').style.backgroundImage = `url("${s.bg}")`;
      const ch = el('story-char');
      ch.classList.remove('show');
      if (s.char) {
        ch.src = s.char;
        void ch.offsetWidth;
        ch.classList.add('show');
      }
      el('story-blackout').classList.remove('on');
    }, 560);
    setTimeout(() => { if (!state.storyActive) return; storyBusy = false; startStoryType(s); }, 640);
  } else {
    if (s.char) {
      const ch = el('story-char');
      ch.classList.remove('show');
      ch.src = s.char;
      void ch.offsetWidth;
      ch.classList.add('show');
    }
    startStoryType(s);
  }
  el('story-name').textContent = s.name;
}

/* 点击屏幕任意处：标题→开始对话；打字中→跳过动画；否则→下一段；最后一段→关闭弹窗进游戏 */
function storyClick() {
  if (!state.storyActive) return;
  if (state.storyPhase === 'title') {
    state.storyPhase = 'dialog';
    el('story-start').classList.remove('show');
    el('story-overlay').classList.remove('title-mode');
    nextStoryLine();
    return;
  }
  if (storyBusy) return;
  if (storyTypeTimer) { finishStoryType(); return; }
  nextStoryLine();
}

/* 剧情结束：弹窗自动淡出，解锁游戏 */
function endStory() {
  state.storyActive = false;
  storyBusy = false;
  if (storyTypeTimer) { clearTimeout(storyTypeTimer); storyTypeTimer = null; }
  stopStoryBGM();   // 剧情音乐停止，进店后切换为酒吧背景音乐
  const ov = el('story-overlay');
  ov.classList.add('hide');
  setTimeout(() => ov.remove(), 700);
  beginGame();
}

function beginGame() {
  // 兜底：跳过剧情入口时也移除剧情遮罩
  const ov = el('story-overlay');
  if (ov) {
    ov.classList.add('hide');
    setTimeout(() => ov.remove(), 100);
  }
  state.gameStarted = true;
  startBGM();                            // 进入酒吧：背景音乐响起（点击触发，符合自动播放策略）
  spawnCustomer();                       // 剧情播完后第一位顾客进店
  state.spawnTimer = spawnInterval();
  addLog('🚀 酒吧开业！摇晃：点壶 / 空格，或点「自动摇酒」，满后自动装杯，点出餐铃上酒', 'welcome');
  renderAll();
}

/* 开场标题：直接展示酒吧外观，下方缓缓浮现「点击开始游戏」 */
function startStory() {
  state.storyActive = true;
  state.storyPhase = 'title';
  const ov = el('story-overlay');
  ov.classList.add('title-mode');
  storyBg = STORY_BG1;
  el('story-bg').style.backgroundImage = `url("${STORY_BG1}")`;
  el('story-char').classList.remove('show');
  startStoryBGM();   // 打开文件立即尝试播放音乐（被浏览器拦截时静音兜底）
  setTimeout(() => el('story-start').classList.add('show'), 550);
}

/* ════════════ 二、状态管理区 ════════════ */
const state = {
  coins: 0,                       // 星币（不清零，跨刷新积累）
  rep: CONFIG.START_REP,          // 声望（不清零，跨刷新积累）
  runs: [],                       // 个人排行榜：每局打烊时的最终声望纪录 [{rep, coins, day, t}]（不清零）
  served: 0,                      // 成功订单数（接待顾客数）
  lost: 0,                        // 流失顾客数（≥20 触发 GameOver）
  perfectCount: 0, goodCount: 0,  // 用于计算好评率
  day: 1, elapsed: 0,             // 第几天 / 累计时长
  queue: [],                      // 排队顾客数组
  nextCustId: 1, spawnTimer: 0,
  nextOrderNo: 1,                 // 订单编号（00001号订单起）
  selectedCustId: null,           // 右侧订单面板展示的顾客（默认队首）
  storyActive: false,             // 开场剧情进行中（屏蔽全部游戏交互）
  storyPhase: 'title',            // 'title'=开场标题（点击开始游戏） / 'dialog'=对话中
  gameStarted: false,             // 剧情播完前不刷客、不计时
  paused: false,                  // 暂停营业（休息中）
  /* 调酒壶：原料列表 / 是否加冰 / 摇晃进度(0-100) / 自动摇酒开关
     shakeSession：摇晃会话号，操作台重置时自增，用于作废未完成的摇晃动画回调 */
  shaker: { items: [], hasIce: false, shaken: false, shaking: false, shakeSession: 0, shakeProgress: 0, autoShake: false },
  /* 酒杯：倒酒后内容快照 / 水果装饰 */
  glass: { filled: false, fruit: null, items: [], hasIce: false, shaken: false },
  soundOn: true,                  // 音效开关
  bgmOn: true,                    // 背景音乐开关
  gameOver: false,
};

/* 背景音乐：内嵌 base64（audios.js）→ WebAudio 解码循环播放 */
let barBuf = null, barSrc = null, barGain = null;
function startBGM() {
  if (!state.bgmOn || state.gameOver || !window.AUDIO_B64) return;
  ensureAudio();
  if (!actx) return;
  if (barBuf) { startBarLoop(); return; }
  actx.decodeAudioData(b64ToBuf(AUDIO_B64.bar), function (buf) {
    barBuf = buf;
    if (state.gameStarted && !state.gameOver) startBarLoop();
  }, function () {});
}
function startBarLoop() {
  pauseBarBGM();
  if (!actx || !barBuf) return;
  barGain = actx.createGain();
  barGain.gain.value = 0.22;
  barGain.connect(actx.destination);
  barSrc = actx.createBufferSource();
  barSrc.buffer = barBuf;
  barSrc.loop = true;
  barSrc.connect(barGain);
  barSrc.start(0);
}
function pauseBarBGM() {
  if (barSrc) { try { barSrc.stop(); } catch (e) {} try { barSrc.disconnect(); } catch (e) {} barSrc = null; }
  if (barGain) { try { barGain.disconnect(); } catch (e) {} barGain = null; }
}
/* 开场剧情音乐：点开文件立即尝试出声播放，无缝循环（WebAudio 采样级循环无间隔），
   一直播放到切换到调酒页面才停止。
   浏览器自动播放限制兜底：若首次出声被拦截则先静音预播，用户首次触碰屏幕时立即出声 */
let storyBuf = null, storySrc = null, storyGain = null;
function b64ToBuf(b64) {
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8.buffer;
}
function startStoryBGM() {
  if (!state.bgmOn || !window.AUDIO_B64) return;
  ensureAudio();
  if (!actx) return;
  if (storyBuf) { startStoryLoop(); return; }
  actx.decodeAudioData(b64ToBuf(AUDIO_B64.story), function (buf) {
    storyBuf = buf;
    if (state.storyActive) startStoryLoop();
  }, function () {});
}
function startStoryLoop() {
  stopStoryBGM();
  if (!actx || !storyBuf) return;
  storyGain = actx.createGain();
  storyGain.gain.value = 0.3;
  storyGain.connect(actx.destination);
  storySrc = actx.createBufferSource();
  storySrc.buffer = storyBuf;
  storySrc.loop = true;
  storySrc.connect(storyGain);
  storySrc.start(0);
}
function stopStoryBGM() {
  if (storySrc) { try { storySrc.stop(); } catch (e) {} try { storySrc.disconnect(); } catch (e) {} storySrc = null; }
  if (storyGain) { try { storyGain.disconnect(); } catch (e) {} storyGain = null; }
}
function toggleBGM() {
  if (state.bgmOn) {
    state.bgmOn = false;
    pauseBarBGM();
    stopStoryBGM();
    toast('🎵 背景音乐已关闭');
  } else {
    state.bgmOn = true;
    if (state.storyActive) startStoryBGM();
    else startBGM();
    toast('🎵 背景音乐已开启');
  }
}

/* 星币与声望不清零：localStorage 跨刷新积累（设置面板可手动清零） */
const SAVE_KEY = 'cyberbar_save_v1';
function saveProgress() {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify({ coins: state.coins, rep: state.rep, runs: state.runs })); } catch (e) {}
}
function loadProgress() {
  try {
    const s = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null');
    if (s && typeof s.coins === 'number' && typeof s.rep === 'number') {
      state.coins = s.coins; state.rep = s.rep;
      state.runs = Array.isArray(s.runs) ? s.runs : [];   // 旧存档无排行榜字段时为空榜
    }
  } catch (e) {}
}

/* 打烊上榜：每局结束（流失满 20 人）把最终声望计入个人排行榜，保留 TOP 10
   返回本次排名（1 起）；被挤出 TOP 10 返回 0 */
function recordRun() {
  const rec = { rep: state.rep, coins: state.coins, day: state.day, t: Date.now() };
  state.runs.push(rec);
  state.runs.sort((a, b) => b.rep - a.rep || b.t - a.t);   // 声望高者在前，同声望新的在前
  if (state.runs.length > 10) state.runs.length = 10;
  saveProgress();
  return state.runs.indexOf(rec) + 1;
}

/* 个人排行榜面板：历史最高声望 TOP 10（每局打烊结算时上榜） */
function renderRankPanel() {
  const list = el('rank-list');
  if (!state.runs.length) {
    list.innerHTML = '<div class="rank-empty">暂无纪录，打完一局自动上榜</div>';
    return;
  }
  const d = t => { const x = new Date(t); return (x.getMonth() + 1) + '月' + x.getDate() + '日'; };
  list.innerHTML = state.runs.map((r, i) =>
    `<div class="rank-item${i === 0 ? ' top' : ''}"><span class="rk-no">${i + 1}</span>` +
    `<span class="rk-main">🌟 ${r.rep} 声望<small>🪙 ${r.coins} 星币 · 第 ${r.day} 天</small></span>` +
    `<span class="rk-time">${d(r.t)}</span></div>`).join('');
}

/* 订单编号文本：00001号订单 */
const orderNoText = no => String(no).padStart(5, '0') + '号订单';

/* 阿拉伯数字 → 中文（用于第N天显示） */
const CN_DIGITS = '零一二三四五六七八九';
function cnNum(n) {
  if (n <= 10) return CN_DIGITS[n];
  if (n < 20) return '十' + (n % 10 ? CN_DIGITS[n % 10] : '');
  return CN_DIGITS[Math.floor(n / 10)] + '十' + (n % 10 ? CN_DIGITS[n % 10] : '');
}

const el = id => document.getElementById(id);
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const rand = (min, max) => min + Math.random() * (max - min);
const countMap = arr => arr.reduce((m, k) => ((m[k] = (m[k] || 0) + 1), m), {});
const ingOf = id => INGREDIENTS.find(i => i.id === id);
const fruitOf = id => FRUITS.find(f => f.id === id);

/* ════════════ 三、渲染区 ════════════ */

/* 顶部 HUD（带脏检查，避免每帧重写 DOM） */
function renderHUD() {
  const set = (id, v) => {
    const b = el(id).querySelector('b');
    if (b.dataset.v !== String(v)) { b.dataset.v = v; b.textContent = v; }
  };
  set('hud-coins', state.coins);
  set('hud-rep', state.rep);
  set('hud-day', '第' + cnNum(state.day) + '天');   // 第一天 / 第二天 / ……
  set('hud-lost', state.lost);
  el('hud-lost').classList.toggle('warn', state.lost >= CONFIG.MAX_LOST - 5);
}

/* 原料架：分类页签 + 按钮 */
let shelfCat = 'spirit';
function buildShelf() {
  el('shelf-tabs').addEventListener('click', e => {
    const b = e.target.closest('[data-cat]');
    if (!b) return;
    shelfCat = b.dataset.cat;
    el('shelf-tabs').querySelectorAll('[data-cat]').forEach(t => t.classList.toggle('active', t === b));
    renderShelf();
  });
  renderShelf();
}
function renderShelf() {
  el('shelf-grid').innerHTML = INGREDIENTS
    .filter(i => i.cat === shelfCat)
    .map(i => `<button class="shelf-btn" data-ing="${i.id}"><span class="shelf-dot" style="background:${i.color}"></span>${i.name}</button>`)
    .join('');
  el('shelf-grid').querySelectorAll('.shelf-btn').forEach(b =>
    b.addEventListener('click', () => addIngredient(ingOf(b.dataset.ing), b)));
}

/* 小料行（操作区下方） */
function buildGarnish() {
  el('garnish-row').innerHTML = INGREDIENTS
    .filter(i => i.cat === 'garnish')
    .map(i => `<button class="garnish-btn" data-ing="${i.id}"><span class="shelf-dot" style="background:${i.color}"></span>${i.name}</button>`)
    .join('');
  el('garnish-row').querySelectorAll('.garnish-btn').forEach(b =>
    b.addEventListener('click', () => addIngredient(ingOf(b.dataset.ing), b)));
}

/* 水果区 */
function buildFruit() {
  el('fruit-panel').innerHTML = FRUITS
    .map(f => `<button class="fruit-btn" data-fruit="${f.id}"><span class="fr-ico" style="background:${f.bg}">${f.emoji}</span>${f.name}</button>`)
    .join('');
  el('fruit-panel').querySelectorAll('.fruit-btn').forEach(b =>
    b.addEventListener('click', () => addFruit(fruitOf(b.dataset.fruit))));
}

/* 调酒壶状态同步到挂载容器（3D 模型对接点） */
function syncMountState() {
  const m = el('shaker-mount');
  let s;
  if (state.shaker.shaking) s = 'shaking';
  else if (state.shaker.shaken) s = 'shaken';
  else if (state.shaker.items.length > 0) s = 'filled';
  else s = 'empty';
  m.dataset.state = s;
}

/* 摇酒壶内液体渲染：分层配色（倒入原料后壶内颜色全部可见） */
function renderShakerLiquid() {
  const liq = el('shaker-liquid');
  liq.innerHTML = '';
  if (state.shaker.items.length) {
    liq.innerHTML = state.shaker.items
      .map(id => `<div class="lg-layer" style="background:${ingOf(id).color}"></div>`)
      .join('');
    liq.style.height = Math.min(100, 14 + state.shaker.items.length * 17) + '%';
  } else {
    liq.style.height = '0%';
  }
}

/* 操作台渲染：挂载容器状态 + 壶内液体 + 原料标签 + 状态文字 */
function renderStation() {
  syncMountState();
  renderShakerLiquid();
  const parts = [];
  if (state.shaker.hasIce) parts.push('<span class="chip">🧊</span>');
  for (const id of state.shaker.items) {
    const ing = ingOf(id);
    parts.push(`<span class="chip"><i style="background:${ing.color}"></i>${ing.name}</span>`);
  }
  el('shaker-chips').innerHTML = parts.join('') || '<span class="chip-dim">壶内空空</span>';
  const st = el('shaker-status');
  if (state.shaker.shaking) st.textContent = '🌀 摇晃中… ' + Math.round(state.shaker.shakeProgress) + '%';
  else if (state.shaker.shaken) st.textContent = '✅ 已摇晃，自动装杯中';
  else if (state.shaker.items.length) st.textContent = '⏳ 待摇晃（点击壶 / 空格 / 自动摇酒）';
  else st.textContent = '未放原料';
}

/* 酒杯渲染：液体分层配色 + 动态高度 + 水果装饰 */
function renderGlass() {
  const liq = el('glass-liquid');
  liq.innerHTML = '';
  if (state.glass.filled) {
    liq.innerHTML = state.glass.items
      .map(id => `<div class="lg-layer" style="background:${ingOf(id).color};opacity:.85"></div>`)
      .join('');
    liq.style.height = (18 + state.glass.items.length * 18) + '%';
  } else {
    liq.style.height = '0%';
  }
  const f = el('glass-fruit');
  f.innerHTML = state.glass.fruit
    ? `<span class="fr-ico" style="background:${fruitOf(state.glass.fruit).bg}">${fruitOf(state.glass.fruit).emoji}</span>`
    : '';
}

/* 耐心条配色：绿 → 黄 → 红（快超时变色预警） */
function patienceColor(pct) {
  return pct > 40 ? 'var(--ok)' : pct > 20 ? 'var(--warn)' : 'var(--danger)';
}

/* 刷新单个顾客的全部耐心 UI（中间头顶气泡 + 右侧列表 + 需求面板） */
function updatePatienceUI(c) {
  const pct = Math.max(0, c.patience / c.maxPatience * 100);
  const color = patienceColor(pct);
  const sec = Math.ceil(c.patience) + 's';
  const low = pct <= 20;
  if (c.ui) {
    for (const f of [c.ui.cFill, c.ui.rFill, c.ui.pFill]) {
      if (f) { f.style.width = pct + '%'; f.style.background = color; }
    }
    if (c.ui.cSec) c.ui.cSec.textContent = sec;
    if (c.ui.rSec) c.ui.rSec.textContent = sec;
    if (c.ui.pSec) c.ui.pSec.textContent = sec;
    if (c.ui.cBubble) c.ui.cBubble.classList.toggle('low', low);
    if (c.ui.rCard) c.ui.rCard.classList.toggle('low', low);
  }
}

/* 中间：排队顾客 + 头顶信息（订单号/耐心/头像/名字 + 出场气泡台词） */
function renderQueueLine() {
  const wrap = el('queue-line');
  if (!state.queue.length) {
    wrap.innerHTML = '<div class="q-empty">暂无顾客排队…</div>';
    return;
  }
  wrap.innerHTML = '';
  const frontId = state.queue[0].id;
  state.queue.forEach(c => {
    c.ui = {};  // 重建 DOM 引用
    const node = document.createElement('div');
    node.className = 'q-cust'
      + (c.id === frontId ? ' front' : '')
      + (c.id === state.selectedCustId ? ' sel' : '');
    node.dataset.cust = c.id;
    // 头像：角色立绘 / 神秘黑块 / emoji
    const avatarInner = c.avatarImg
      ? `<img class="q-avatar-img" src="${c.avatarImg}" alt="">`
      : (c.mystery ? '<span class="q-avatar-box"></span>' : `<span class="q-avatar-emoji">${c.avatarEmoji}</span>`);
    // 台词气泡：轮到调他的酒时（成为队首）才弹出，约5秒后消失；
    // 重渲染时用负 animation-delay 续播，避免气泡闪烁重播
    const QUOTE_LIFE = 5200;
    const quoteElapsed = c.quoteShownAt != null ? Date.now() - c.quoteShownAt : -1;
    const showQuote = c.quote && c.id === frontId && (c.quoteShownAt == null || quoteElapsed < QUOTE_LIFE);
    if (showQuote && c.quoteShownAt == null) c.quoteShownAt = Date.now();
    const quoteDelay = c.quoteShownAt != null ? Math.min(0, -(Date.now() - c.quoteShownAt)) : 0;
    node.innerHTML = `
      ${showQuote ? `<div class="q-quote" style="animation-delay:${quoteDelay}ms">${c.quote}</div>` : ''}
      <div class="q-name">${c.name}</div>
      <div class="pat-bubble">
        <div class="pat-bar"><div class="pat-fill"></div></div>
        <span class="pat-sec"></span>
      </div>
      <div class="q-avatar${c.avatarImg ? ' has-img' : ''}${c.mystery ? ' mystery' : ''}">${avatarInner}${c.id === frontId ? '<span class="q-front-badge">⭐</span>' : ''}</div>`;
    // 出场动画：斯沃德麦伦从下往上，其余弹入
    node.classList.add(c.entrance === 'up' ? 'enter-up' : 'enter-pop');
    c.ui.cFill = node.querySelector('.pat-fill');
    c.ui.cSec = node.querySelector('.pat-sec');
    c.ui.cBubble = node.querySelector('.pat-bubble');
    wrap.appendChild(node);
    updatePatienceUI(c);
  });
  // 队首（正在调酒的客人）居中显示，不靠向日志一侧：
  // 窄队列 → 整体右移使队首居中；宽队列 → 滚动到队首居中（可达范围内）
  const zone = el('bar-zone');
  const frontNode = wrap.querySelector('.q-cust.front');
  if (frontNode) {
    // 队首中心相对 queue-line（用 rect 差值，offsetLeft 的参照可能不是 queue-line）
    const wr = wrap.getBoundingClientRect();
    const fr = frontNode.getBoundingClientRect();
    /* 旋转 90° 时游戏内水平方向 = 屏幕垂直方向，用 top 差值换算，保证队首真正居中 */
    const rotS = window.__rotSign || 0;
    const P = rotS ? (fr.top - wr.top) * rotS + frontNode.offsetWidth / 2 : (fr.left - wr.left) + frontNode.offsetWidth / 2;
    const zoneW = zone.clientWidth;
    const shift = zoneW / 2 - P;
    if (shift >= 0) {
      // 平移队列使队首居中；右侧超出部分可横向滑动查看
      wrap.style.marginLeft = shift + 'px';
      wrap.style.marginRight = 'auto';
      zone.scrollLeft = 0;
    } else {
      wrap.style.marginLeft = '';
      wrap.style.marginRight = '';
      zone.scrollLeft = Math.max(0, Math.min(P - zoneW / 2, zone.scrollWidth - zoneW));
    }
  }
}

/* 右侧：订单面板（身份 / 台词 / 逐行需求 / 耐心 / 奖励，只有摇晃没有搅拌） */
function renderOrderPanel() {
  const p = el('order-panel');
  const c = state.queue.find(x => x.id === state.selectedCustId) || state.queue[0] || null;
  if (!c) {
    p.innerHTML = '<div class="cp-empty">柜台前空无一人…</div>';
    return;
  }
  const headAvatar = c.avatarImg
    ? `<img class="cp-avatar-img" src="${c.avatarImg}" alt="">`
    : (c.mystery ? '<span class="cp-avatar-box"></span>' : `<span class="cp-avatar-emoji">${c.avatarEmoji}</span>`);  const quoteLine = c.arriveLine ? `<div class="cp-quote">『${c.arriveLine}』</div>` : '';
  // 「无可奉告」：神秘订单，随便给什么都行
  if (c.mystery || !c.recipe) {
    p.innerHTML = `
      <div class="cp-head">
        <span class="cp-avatar${c.avatarImg ? ' has-img' : ''}">${headAvatar}</span>
        <div class="cp-main">
          <div class="cp-name">${c.name}${c.race ? `<span class="cp-race">${c.race}</span>` : ''}<span class="order-no">${orderNoText(c.orderNo)}</span></div>
          ${quoteLine}
        </div>
      </div>
      <div class="mystery-block">❓ 无可奉告<br><small>随便给点什么吧</small></div>
      <div class="cp-bottom">
        <div class="cp-pat"><div class="pat-bar"><div class="pat-fill"></div></div><span class="cp-sec"></span></div>
        <div class="cp-reward">💰 50</div>
      </div>`;
    c.ui = c.ui || {};
    c.ui.pFill = p.querySelector('.pat-fill');
    c.ui.pSec = p.querySelector('.cp-sec');
    updatePatienceUI(c);
    return;
  }
  const rec = c.recipe;
  // 需求按固定顺序排列：冰块 → 基底酒 → 利口酒 → 果汁 → 配料 → 小料 → 摇酒 → 装饰
  // 行首显示类别名，具体品名以小标签缀在右侧
  const CAT_LABEL = { spirit: '基底酒', liqueur: '利口酒', juice: '果汁', mixer: '配料', garnish: '小料' };
  const CAT_ORDER = { spirit: 1, liqueur: 2, juice: 3, mixer: 4, garnish: 5 };
  const rows = [
    { o: -1, html: `<div class="order-row drink-name"><i style="background:${rec.color}"></i><span>${rec.name}</span><span class="or-tag">${rec.owner}</span></div>` },
    { o: 0, html: '<div class="order-row ice">🧊<span>冰块</span><span class="or-tag">必须</span></div>' },
    ...rec.ingredients.map(id => {
      const i = ingOf(id);
      const cat = CAT_LABEL[i.cat] || i.cat;
      // 品名在前，类别标签缀后（如 柠檬汁 [果汁]），方便去货架寻找
      return { o: CAT_ORDER[i.cat] || 9, html: `<div class="order-row"><i style="background:${i.color}"></i><span>${i.name}</span><span class="or-tag">${cat}</span></div>` };
    }),
    rec.needsShake ? { o: 6, html: '<div class="order-row shake">🌀<span>摇酒操作</span></div>' } : null,
    rec.fruit ? { o: 7, html: `<div class="order-row"><i style="background:${fruitOf(rec.fruit).bg}"></i><span>${fruitOf(rec.fruit).name}</span><span class="or-tag">装饰</span></div>` } : null,
  ].filter(Boolean).sort((a, b) => a.o - b.o).map(x => x.html).join('');
  p.innerHTML = `
    <div class="cp-head">
      <span class="cp-avatar${c.avatarImg ? ' has-img' : ''}">${headAvatar}</span>
      <div class="cp-main">
        <div class="cp-name">${c.name}${c.race ? `<span class="cp-race">${c.race}</span>` : ''}<span class="order-no">${orderNoText(c.orderNo)}</span></div>
        ${quoteLine}
      </div>
    </div>
    <div class="order-rows">${rows}</div>
    <div class="cp-bottom">
      <div class="cp-pat"><div class="pat-bar"><div class="pat-fill"></div></div><span class="cp-sec"></span></div>
      <div class="cp-reward">💰 ${rec.reward}</div>
    </div>`;
  c.ui = c.ui || {};
  c.ui.pFill = p.querySelector('.pat-fill');
  c.ui.pSec = p.querySelector('.cp-sec');
  updatePatienceUI(c);
}

/* 制作进度（冰→料→摇→倒→果→铃，用于按铃就绪判定） */
function currentStep() {
  if (!state.shaker.hasIce) return 1;
  if (state.shaker.items.length === 0) return 2;
  const front = state.queue[0];
  const needShake = front && front.recipe ? front.recipe.needsShake : true;   // 神秘订单也按需要摇晃处理
  if (needShake && !state.shaker.shaken) return 3;
  if (!state.glass.filled) return 4;
  if (front && front.recipe && front.recipe.fruit && !state.glass.fruit) return 5;
  return 6;
}
function renderFlow() {
  // 按铃就绪：酒已备好且有顾客等待时发光提示
  el('btn-bell').classList.toggle('ready-glow', currentStep() === 6 && state.queue.length > 0);
}

/* 酒吧日志（最新在最上） */
function addLog(text, cls) {
  const list = el('log-list');
  const d = document.createElement('div');
  d.className = 'log-item ' + (cls || '');
  d.textContent = text;
  list.prepend(d);
  while (list.children.length > 60) list.removeChild(list.lastChild);
}

/* 底部 Toast */
function toast(msg) {
  const wrap = el('toast-wrap');
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  wrap.appendChild(t);
  while (wrap.children.length > 3) wrap.removeChild(wrap.firstChild);
  setTimeout(() => t.classList.add('out'), 1600);
  setTimeout(() => t.remove(), 2000);
}

/* 星币入账飞行动画（按铃 → HUD 星币） */
function coinFly(amount) {
  const bell = el('btn-bell').getBoundingClientRect();
  const target = el('hud-coins').getBoundingClientRect();
  const fly = document.createElement('div');
  fly.className = 'coin-fly';
  fly.textContent = `+${amount} 🪙`;
  document.body.appendChild(fly);
  const r = fly.getBoundingClientRect();
  fly.style.left = (bell.left + bell.width / 2 - r.width / 2) + 'px';
  fly.style.top = (bell.top - 10) + 'px';
  fly.animate([
    { transform: 'translate(0, 0) scale(1)', opacity: 1 },
    { transform: `translate(${target.left - bell.left}px, ${target.top - bell.top}px) scale(.55)`, opacity: .9, offset: .75 },
    { transform: `translate(${target.left - bell.left}px, ${target.top - bell.top}px) scale(.4)`, opacity: 0 },
  ], { duration: 900, easing: 'cubic-bezier(.25,.6,.35,1)' }).onfinish = () => fly.remove();
}

function renderAll() {
  renderHUD();
  renderStation();
  renderGlass();
  renderQueueLine();
  renderOrderPanel();
  renderFlow();
}

/* ════════════ 四、交互区（点击 / 滑动） ════════════ */

/* 摇酒进度条归零（无过渡动画，立刻清空） */
function resetProgress() {
  state.shaker.shakeProgress = 0;
  const fill = el('shake-progress-fill');
  fill.style.transition = 'none';
  fill.style.width = '0%';
  fill.classList.remove('done');
}

/* 步骤1：加冰块 */
function addIce() {
  if (!state.gameStarted || state.paused || state.gameOver) return;
  if (state.glass.filled) return toast('杯子里有酒了，先上酒');
  if (state.shaker.hasIce) return toast('冰块已经加好了');
  state.shaker.hasIce = true;
  if (state.shaker.shaken) { state.shaker.shaken = false; state.shaker.shakeSession++; resetProgress(); }
  const m = el('shaker-mount');
  m.classList.remove('splash'); void m.offsetWidth; m.classList.add('splash');
  toast('🧊 冰块入壶');
  playSound('ice');
  renderStation(); renderFlow();
}

/* 步骤2：添加原料（基酒/利口酒/果汁/小料，无光束特效） */
function addIngredient(ing, btnEl) {
  if (!state.gameStarted || state.paused || state.gameOver) return;
  if (state.glass.filled) return toast('杯子里有酒了，先上酒');
  if (state.shaker.items.length >= CONFIG.SHAKER_CAPACITY) return toast('调酒壶已满，先倒酒吧！');
  state.shaker.items.push(ing.id);
  if (state.shaker.shaken) { state.shaker.shaken = false; state.shaker.shakeSession++; resetProgress(); }
  // 反馈：酒瓶倾斜 + 酒壶水花（已按要求去除添加酒品时的光束）
  if (btnEl) {
    btnEl.classList.remove('tip'); void btnEl.offsetWidth; btnEl.classList.add('tip');
  }
  const m = el('shaker-mount');
  m.classList.remove('splash'); void m.offsetWidth; m.classList.add('splash');
  toast(`+ ${ing.name}`);
  playSound('pour');
  renderStation(); renderFlow();
}

/* 步骤3：摇晃调酒壶（三种手动方式并行叠加进度）
   ①点击调酒壶 ②键盘空格；另有「自动摇酒」按钮匀速自动摇
   每次操作增加进度，进度涨满自动完成摇晃并倒酒装杯 */
function startShake() {
  if (!state.gameStarted || state.paused || state.gameOver) return false;
  if (state.shaker.shaken) return false;
  if (state.shaker.items.length === 0) { toast('请先添加调酒原料'); return false; }
  if (!state.shaker.shaking) {
    state.shaker.shaking = true;
    const mount = el('shaker-mount');
    mount.classList.add('shake');           // 调酒壶摇动动画（与进度条同步播放）
    mount.dataset.state = 'shaking';
    document.body.classList.add('shake-vibrate');
    setTimeout(() => document.body.classList.remove('shake-vibrate'), 500);
    playSound('shake');
    renderStation(); renderFlow();
  }
  return true;
}
function addShakeProgress(pct) {
  if (!startShake()) return;
  state.shaker.shakeProgress = Math.min(100, state.shaker.shakeProgress + pct);
  renderShakeProgress();
  if (state.shaker.shakeProgress >= 100) finishShake();
}
function renderShakeProgress() {
  const fill = el('shake-progress-fill');
  fill.style.width = state.shaker.shakeProgress + '%';
  fill.classList.toggle('done', state.shaker.shaken);
}
function finishShake() {
  state.shaker.shaking = false;
  state.shaker.shaken = true;
  const mount = el('shaker-mount');
  mount.classList.remove('shake');
  mount.dataset.state = 'shaken';
  el('shake-progress-fill').classList.add('done');
  toast('✅ 摇晃完成！自动装杯…');
  playSound('shakeDone');
  vibrate(30);
  renderStation(); renderFlow();
  // 进度满后自动切换到鸡尾酒杯装盘画面（自动倒酒）
  setTimeout(() => {
    if (state.shaker.shaken && !state.glass.filled) pourGlass();
  }, 400);
}

/* 手动摇酒：点击调酒壶（带冷却，连续点击持续叠加进度） */
let lastShakeClick = 0;
function manualShakeClick() {
  const now = performance.now();
  if (now - lastShakeClick < CONFIG.SHAKE_CLICK_COOLDOWN) return;
  lastShakeClick = now;
  addShakeProgress(CONFIG.SHAKE_CLICK_GAIN);
}

/* 自动摇酒：按钮开关，匀速自动增长进度；运行中手动操作仍可叠加 */
function toggleAutoShake() {
  if (!state.gameStarted || state.paused || state.gameOver) return;
  state.shaker.autoShake = !state.shaker.autoShake;
  el('btn-auto-shake').classList.toggle('on', state.shaker.autoShake);
  el('btn-auto-shake').textContent = state.shaker.autoShake ? '⏹ 停止自动摇酒' : '🤖 自动摇酒';
  if (state.shaker.autoShake) toast('🤖 自动摇酒开启');
  playSound('click');
}

/* 步骤4：点击杯子倒酒出壶 */
function pourGlass() {
  if (!state.gameStarted || state.paused || state.gameOver) return;
  if (state.glass.filled) return toast('杯子已满，先上酒');
  if (state.shaker.items.length === 0) return toast('酒壶是空的，请先添加原料');
  const front = state.queue[0];
  const needShake = front && front.recipe ? front.recipe.needsShake : true;
  if (needShake && !state.shaker.shaken) return toast('请先摇晃调酒壶！');
  // 内容快照进酒杯
  state.glass.items = [...state.shaker.items];
  state.glass.hasIce = state.shaker.hasIce;
  state.glass.shaken = state.shaker.shaken;
  state.glass.filled = true;
  // 清空调酒壶，进度条立刻归零
  state.shaker.items = [];
  state.shaker.hasIce = false;
  state.shaker.shaken = false;
  state.shaker.shaking = false;
  state.shaker.shakeSession++;
  resetProgress();
  // 倒酒动画：挂载容器附加 pouring 类倾斜（已去除倒酒光线）
  const mount = el('shaker-mount');
  mount.classList.remove('shake');
  mount.classList.add('pouring');
  mount.dataset.state = 'pouring';
  setTimeout(() => { mount.classList.remove('pouring'); syncMountState(); }, 700);
  toast('🍸 已倒入酒杯');
  playSound('pour');
  renderGlass(); renderStation(); renderFlow();
}

/* 步骤5：水果装饰（顾客要水果时必须给，但可以乱给） */
function addFruit(f) {
  if (!state.gameStarted || state.paused || state.gameOver) return;
  if (!state.glass.filled) return toast('请先倒酒再装饰水果');
  if (state.glass.fruit) return toast('水果装饰已添加');
  state.glass.fruit = f.id;
  toast(`+ ${f.name}`);
  playSound('click');
  renderGlass(); renderFlow();
}

/* 步骤6：点击出餐铃交付顾客，结算得分 */
function ringBell() {
  if (!state.gameStarted || state.paused || state.gameOver) return;
  const b = el('btn-bell');
  if (!state.glass.filled) return toast('杯子里还没有酒，请先倒酒');
  if (!state.queue.length) return toast('没有顾客在等待');
  const cust = state.queue[0];
  if (cust.recipe && cust.recipe.fruit && !state.glass.fruit) return toast('顾客需要水果装饰，请先添加水果');
  b.classList.remove('ring'); void b.offsetWidth; b.classList.add('ring');
  playSound('bell');
  settle(cust);
}

/* 点选排队顾客 → 右侧订单面板展示该顾客 */
function selectCustomer(id) {
  if (!state.gameStarted || state.paused) return;
  if (!state.queue.some(c => c.id === id)) return;
  state.selectedCustId = id;
  playSound('click');
  renderQueueLine(); renderOrderPanel();
}

/* ─── 中间吧台区：拖拽横向滑动（点击与滑动互不冲突） ───
   按下后位移 ≤8px 判定为点击（正常触发按钮逻辑）；
   位移 >8px 判定为滑动，滚动操作台并吞掉随后产生的 click，避免误触。 */
function initDragScroll() {
  const zone = el('bar-zone');
  let drag = null, suppressClick = false;
  zone.addEventListener('pointerdown', e => {
    suppressClick = false;
    if (e.button !== undefined && e.button !== 0) return;
    drag = { startX: e.clientX, startY: e.clientY, startScroll: zone.scrollLeft, moved: false, id: e.pointerId };
  });
  zone.addEventListener('pointermove', e => {
    if (!drag || e.pointerId !== drag.id) return;
    /* 画面旋转 90° 时（竖屏容器）：游戏内横向滚动对应屏幕纵向位移（rotate 90° → +y；-90° → -y） */
    const rotated = window.__rotSign || 0;
    const dx = rotated ? (e.clientY - drag.startY) * rotated : (e.clientX - drag.startX);
    if (!drag.moved && Math.abs(dx) > 6) {   /* 触摸位移阈值 6px：小于=点击，大于=滑动 */
      drag.moved = true;
      zone.classList.add('dragging');
      try { zone.setPointerCapture(e.pointerId); } catch (err) {}
    }
    if (drag.moved) {
      zone.scrollLeft = drag.startScroll - dx;
      e.preventDefault();
    }
  });
  const endDrag = e => {
    if (!drag || e.pointerId !== drag.id) return;
    if (drag.moved) suppressClick = true;
    drag = null;
    zone.classList.remove('dragging');
  };
  zone.addEventListener('pointerup', endDrag);
  zone.addEventListener('pointercancel', endDrag);
  zone.addEventListener('contextmenu', e => e.preventDefault());
  // 滑动结束后吞掉随后的一次 click（下一轮 pointerdown 会复位该标记）
  document.addEventListener('click', e => {
    if (suppressClick) { e.preventDefault(); e.stopPropagation(); suppressClick = false; }
  }, true);
  // 电脑端鼠标滚轮 → 横向滚动
  zone.addEventListener('wheel', e => {
    if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) zone.scrollLeft += e.deltaY;
  }, { passive: true });
}


/* 必须在用户首次点击页面后调用（浏览器安全策略） */


/* 首次点击页面：初始化音频 + 音乐兜底启动（剧情中→剧情音乐出声，游戏中→酒吧音乐） */
function onFirstTap() {
  document.removeEventListener('pointerdown', onFirstTap);
  ensureAudio();
  if (state.storyActive) startStoryBGM();   // 首次触碰：出声兜底（此前被静音拦截的话）
  else if (state.gameStarted) startBGM();
}

/* ════════════ 五、顾客与结算逻辑 ════════════ */

/* 刷客间隔：初始缓慢，从第 5 天起逐渐加快 */
function spawnInterval() {
  const ramp = Math.max(0, state.day - 5) * CONFIG.SPAWN_RAMP;
  return Math.max(CONFIG.SPAWN_MIN, CONFIG.SPAWN_BASE - ramp);
}

/* 按天数加权挑选配方（越往后复杂配方占比越高） */
function pickRecipe() {
  const d = state.day;
  const weights = RECIPES.map(r => {
    if (r.diff === 1) return Math.max(0.8, 4 - d * 0.7);
    if (r.diff === 2) return 2.5;
    return Math.min(4.5, 0.6 + d * 0.9);
  });
  const total = weights.reduce((a, b) => a + b, 0);
  let roll = Math.random() * total;
  for (let i = 0; i < RECIPES.length; i++) {
    roll -= weights[i];
    if (roll <= 0) return RECIPES[i];
  }
  return RECIPES[RECIPES.length - 1];
}

/* 生成新顾客：单客60s正常；排队等待的人多时耐心适当加长（不仓促）
   角色抽取：星际旅客(主力)62% / 固定角色27% / 无可奉告11%
   保底：每第 4 位必是固定角色（烬行等特殊客人）；排队中不出现重复角色 */
function spawnCustomer() {
  const queuedNames = new Set(state.queue.map(c => c.name));
  const availNamed = CHARACTERS.slice(0, 8).filter(ch => !queuedNames.has(ch.name));
  let char = null;
  if (state.nextOrderNo === 1) {
    char = CHARACTERS.find(c => c.id === 'shrimp');   // 开局第一位顾客固定：虾兵蟹将的将
  }
  if (!char && state.nextOrderNo % 4 === 0 && availNamed.length) {
    char = pick(availNamed);   // 保底：每第 4 位顾客是固定角色
  }
  if (!char) {
    const roll = Math.random();
    if (roll < 0.62) {
      const q = pick(COMMON_QUOTES);
      char = { id: 'common', name: pick(COMMON_NAMES), img: null, quote: q || null, fixedOrder: null };
    } else if (roll < 0.89) {
      char = pick(availNamed.length ? availNamed : CHARACTERS.slice(0, 8));
    } else {
      char = CHARACTERS[8];   // 无可奉告
    }
  }
  const rec = char.mystery ? null
    : (char.fixedOrder ? RECIPES.find(r => r.id === char.fixedOrder) : pickRecipe());
  const waiting = Math.min(state.queue.length, Math.floor(CONFIG.PATIENCE_QUEUE_BONUS_CAP / CONFIG.PATIENCE_QUEUE_BONUS));
  const patience = Math.round(CONFIG.PATIENCE_BASE + waiting * CONFIG.PATIENCE_QUEUE_BONUS + Math.random() * 3);
  const cust = {
    id: state.nextCustId++,
    orderNo: state.nextOrderNo++,
    name: char.name,
    race: char.id === 'common' ? pick(COMMON_RACES) : '',   // 特殊客人不显示种族
    avatarImg: char.img || '',
    avatarEmoji: char.id === 'common' ? pick(RACES).avatar : '',
    mystery: !!char.mystery,
    entrance: char.entrance || '',
    quote: char.quote || null,
    spawnTime: Date.now(),
    recipe: rec,
    patience, maxPatience: patience,
    arriveLine: char.quote || '',
    ui: {},
  };
  state.queue.push(cust);
  if (state.selectedCustId == null) state.selectedCustId = cust.id;
  addLog(cust.mystery
    ? `🛎 神秘的「无可奉告」进店（${orderNoText(cust.orderNo)}）：不知道想要什么…`
    : `🛎 「${cust.name}」进店（${orderNoText(cust.orderNo)}）${rec ? '：想要一杯【' + rec.name + '】' : ''}`, 'arrive');
  toast(`👥 ${cust.name} 排队中`);
  playSound('click');
  renderAll();
}

/* 顾客流失（耐心耗尽 / 排队满员），扣分并检查 GameOver */
function loseCustomer(penaltyText) {
  state.lost++;
  state.coins = Math.max(0, state.coins - CONFIG.LOST_PENALTY_COINS);
  state.rep = Math.max(0, state.rep - CONFIG.LOST_PENALTY_REP);
  saveProgress();
  addLog(penaltyText, 'lost');
  playSound('angry');
  renderHUD();
  checkGameOver();
}

/* 顾客耐心耗尽，生气离开 */
function customerLeave(cust) {
  state.queue = state.queue.filter(c => c.id !== cust.id);
  if (state.selectedCustId === cust.id) state.selectedCustId = state.queue[0] ? state.queue[0].id : null;
  toast(`😠 ${cust.name} 生气离开了！`);
  loseCustomer(`😠 「${cust.name}」等不及走了：『${pick(DIALOGUE.timeout)}』 -${CONFIG.LOST_PENALTY_COINS}🪙`);
  renderAll();
}

/* 排队满员，新顾客扭头就走 */
function overflowLose() {
  toast('🚪 排队满员，新顾客离开了');
  loseCustomer(`🚪 新顾客见排队满员，扭头就走：『${pick(DIALOGUE.overflow)}』`);
}

/* 配方判定：多放/少放/放错/未摇晃/没加冰/水果给错 都会降级 */
function evaluateDrink(cust, drink) {
  if (!cust.recipe) return 'perfect';   // 神秘订单：随便给什么都算完美
  const rec = cust.recipe;
  const want = countMap(rec.ingredients);
  const got = countMap(drink.items);
  let matched = 0;
  for (const k in want) matched += Math.min(want[k], got[k] || 0);
  const ratio = rec.ingredients.length ? matched / rec.ingredients.length : 1;
  let grade = ratio >= 0.999 ? 'perfect' : ratio >= 0.7 ? 'good' : ratio >= 0.4 ? 'bad' : 'fail';
  const down = g => ({ perfect: 'good', good: 'bad', bad: 'fail', fail: 'fail' }[g]);
  if (rec.needsShake && !drink.shaken) grade = down(grade);   // 该摇没摇
  if (!drink.hasIce) grade = down(grade);                     // 没加冰
  if (drink.items.length > matched) grade = down(grade);      // 多放原料
  if (rec.fruit && drink.fruit !== rec.fruit) grade = down(grade); // 水果给错（乱给水果）
  return grade;
}

/* 交付结算：评分 → 星币/声望 → 日志评价 → 清空操作台 */
function settle(cust) {
  const rec = cust.recipe;
  const grade = evaluateDrink(cust, state.glass);
  const g = CONFIG.GRADES[grade];
  const reward = rec ? rec.reward : 50;   // 神秘订单固定奖励
  const coins = Math.round(reward * g.mult);
  state.coins = Math.max(0, state.coins + coins);
  state.rep = Math.max(0, state.rep + g.rep);
  saveProgress();
  state.served++;
  if (grade === 'perfect') state.perfectCount++;
  else if (grade === 'good') state.goodCount++;
  state.queue = state.queue.filter(c => c.id !== cust.id);
  const isGood = grade === 'perfect' || grade === 'good';
  const gotWhat = rec ? `收到${rec.name}` : '收下了一杯神秘特调';
  addLog(`${isGood ? '🌟' : '💢'} 「${cust.name}」${gotWhat}：${g.label}！${coins >= 0 ? '+' : ''}${coins}🪙 『${pick(DIALOGUE[grade])}』`,
    isGood ? 'settle-good' : 'settle-bad');
  coinFly(coins);
  toast(`🍸 ${g.label}！ +${coins} 星币`);
  playSound(isGood ? 'coin' : 'angry');
  vibrate(isGood ? 30 : 0);
  if (state.selectedCustId === cust.id) state.selectedCustId = state.queue[0] ? state.queue[0].id : null;
  resetStation();
  renderAll();
}

/* 交付完成 / 清空操作台：摇酒进度条立刻归零 */
function resetStation() {
  state.shaker = { items: [], hasIce: false, shaken: false, shaking: false, shakeSession: state.shaker.shakeSession + 1, shakeProgress: 0, autoShake: false };
  state.glass = { filled: false, fruit: null, items: [], hasIce: false, shaken: false };
  if (el('btn-auto-shake')) {
    el('btn-auto-shake').classList.remove('on');
    el('btn-auto-shake').textContent = '🤖 自动摇酒';
  }
  resetProgress();
  const m = el('shaker-mount');
  m.classList.remove('shake', 'pouring');
  syncMountState();
}

/* 倒掉重做：一键清空调酒壶与酒杯（做错配方时重新开始，无惩罚） */
function dumpStation() {
  const hasStuff = state.shaker.items.length > 0 || state.shaker.hasIce || state.glass.filled;
  if (!hasStuff && !state.shaker.shaking && !state.shaker.shaken) return toast('操作台空空如也，没什么可倒的');
  resetStation();
  toast('🗑 已倒掉，重新开始调制');
  playSound('dump');
  renderAll();
}

/* GameOver 检查 */
function checkGameOver() {
  if (!state.gameOver && state.lost >= CONFIG.MAX_LOST) {
    state.gameOver = true;
    showGameOver();
  }
}
function showGameOver() {
  el('go-coins').textContent = state.coins;
  el('go-served').textContent = state.served;
  el('go-rate').textContent = (state.served
    ? Math.round((state.perfectCount + state.goodCount) / state.served * 100)
    : 0) + '%';
  el('go-lost').textContent = state.lost;
  el('go-day').textContent = state.day;
  el('go-rep').textContent = state.rep;
  const rank = recordRun();
  el('go-rank').textContent = rank > 0 ? '第 ' + rank + ' 名' : '未上榜';
  el('gameover-overlay').classList.remove('hidden');
  playSound('angry');
  vibrate(80);
}

/* ════════════ 五·五、暂停营业（休息） ════════════ */
function togglePause() {
  if (!state.gameStarted) return;
  state.paused = !state.paused;
  el('btn-pause').classList.toggle('paused', state.paused);
  el('btn-pause').innerHTML = state.paused ? '▶ 继续' : '⏸ 暂停';
  el('pause-overlay').classList.toggle('hidden', !state.paused);
  // 背景音乐随暂停休息一同暂停/恢复
  if (state.bgmOn) {
    if (state.paused) pauseBarBGM();
    else startBGM();
  }
  playSound('click');
  if (state.paused) toast('☕ 暂停营业，休息一下');
}

/* ════════════ 六、音效（WebAudio 合成，零外部资源） ════════════ */
let actx = null;
function ensureAudio() {
  if (!actx) {
    try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {}
  }
  if (actx && actx.state === 'suspended') actx.resume().catch(() => {});
}
function tone(freq, dur = 0.15, type = 'sine', vol = 0.12, slideTo = null, delay = 0) {
  if (!actx || !state.soundOn) return;
  try {
    const t0 = actx.currentTime + delay;
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(1, slideTo), t0 + dur);
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(actx.destination);
    o.start(t0); o.stop(t0 + dur + 0.03);
  } catch (e) {}
}
function noiseBurst(dur = 0.25, vol = 0.1, cutoff = 1200, delay = 0) {
  if (!actx || !state.soundOn) return;
  try {
    const t0 = actx.currentTime + delay;
    const n = Math.floor(actx.sampleRate * dur);
    const buf = actx.createBuffer(1, n, actx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < n; i++) data[i] = Math.random() * 2 - 1;
    const src = actx.createBufferSource(); src.buffer = buf;
    const f = actx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = cutoff;
    const g = actx.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f); f.connect(g); g.connect(actx.destination);
    src.start(t0);
  } catch (e) {}
}
function playSound(type) {
  ensureAudio();
  if (!actx || !state.soundOn) return;
  switch (type) {
    case 'click':     tone(1100, .04, 'sine', .07, 1850); tone(2400, .03, 'sine', .035, null, .02); break;   // 清脆上扬短音
    case 'ice':       tone(1400, .07, 'sine', .08); tone(900, .09, 'sine', .07, null, .07); break;
    case 'pour':      noiseBurst(.3, .07, 900); break;
    case 'dump':      tone(560, .16, 'sine', .1, 240); tone(320, .3, 'sine', .1, 150, .14); break;   // 倒掉：下滑的水声
    case 'shake':     noiseBurst(.18, .09, 700); noiseBurst(.18, .08, 500, .16); break;
    case 'shakeDone': tone(880, .12, 'sine', .1); tone(1318, .2, 'sine', .09, null, .1); break;
    case 'bell':      tone(1319, .1, 'sine', .1); tone(1760, .14, 'sine', .08, null, .05); tone(2637, .12, 'sine', .05, null, .1); break;   // 清脆铃音
    case 'coin':      tone(988, .08, 'sine', .09); tone(1319, .22, 'sine', .09, null, .08); break;
    case 'angry':     tone(240, .28, 'sawtooth', .09, 110); break;
    case 'tick':      tone(1650, .02, 'sine', .03); break;
  }
}
function vibrate(ms) {
  if (!ms) return;
  try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {}
}

/* ════════════ 七、游戏主循环与初始化 ════════════ */

/* 主循环：100ms 一次心跳（天数 / 刷客 / 耐心倒计时 / HUD）
   剧情未播完 / 暂停休息时不推进游戏 */
function tick(dt) {
  if (state.gameOver || state.paused || !state.gameStarted) return;
  state.elapsed += dt;
  // 天数推进：顾客刷新变快、耐心变短、复杂配方变多
  const newDay = Math.floor(state.elapsed / CONFIG.DAY_SECONDS) + 1;
  if (newDay !== state.day) {
    state.day = newDay;
    addLog(`🌅 第 ${newDay} 天：生意更忙了，顾客的耐心更少了！`, 'day');
    toast(`🌅 第 ${newDay} 天`);
  }
  // 自动刷客
  state.spawnTimer -= dt;
  if (state.spawnTimer <= 0) {
    if (state.queue.length >= CONFIG.MAX_QUEUE) overflowLose();
    else spawnCustomer();
    state.spawnTimer = spawnInterval() + Math.random() * 2;
  }
  // 顾客耐心倒计时（全员同时流逝）
  for (const c of [...state.queue]) {
    c.patience -= dt;
    if (c.patience <= 0) { c.patience = 0; customerLeave(c); continue; }
    updatePatienceUI(c);
  }
  // 自动摇酒：匀速自动增长进度（手动操作可叠加）
  if (state.shaker.autoShake && state.shaker.items.length > 0 && !state.shaker.shaken) {
    addShakeProgress(CONFIG.SHAKE_AUTO_RATE);
  }
  renderHUD();
  renderFlow();
}

function init() {
  loadProgress();  // 星币与声望不清零：恢复上次存档
  // 应用背景图（包内文件；BG_IMAGE 为空时回退 CSS 星空）
  if (BG_IMAGE) {
    el('bg-layer').style.backgroundImage = `url("${BG_IMAGE}")`;   /* 超大背景层：横屏方向、比屏幕大，旋转后填满无死角 */
    el('bg-layer').classList.add('has-photo');
  }
  buildShelf();
  buildFruit();
  buildGarnish();

  /* ── 事件绑定 ── */
  // 摇酒：①点击调酒壶（每次点击叠加进度）
  el('shaker-mount').addEventListener('click', manualShakeClick);
  // ②键盘空格（全局，每次按下叠加进度；preventDefault 防止误触聚焦按钮）
  document.addEventListener('keydown', e => {
    if (e.code !== 'Space') return;
    if (!state.gameStarted || state.paused || state.gameOver || state.storyActive) return;
    e.preventDefault();
    manualShakeClick();
  });
  // 自动摇酒开关
  el('btn-auto-shake').addEventListener('click', toggleAutoShake);
  // 倒掉重做：清空壶与杯
  el('btn-dump').addEventListener('click', dumpStation);
  el('btn-ice').addEventListener('click', addIce);
  el('btn-pour').addEventListener('click', pourGlass);
  el('btn-bell').addEventListener('click', ringBell);
  el('btn-settings').addEventListener('click', () => { el('rank-panel').classList.add('hidden'); el('settings-panel').classList.toggle('hidden'); });
  // 个人排行榜：与设置面板互斥，打开时刷新数据
  el('btn-rank').addEventListener('click', () => {
    el('settings-panel').classList.add('hidden');
    const p = el('rank-panel');
    p.classList.toggle('hidden');
    if (!p.classList.contains('hidden')) renderRankPanel();
  });
  el('btn-restart').addEventListener('click', () => location.reload());

  // 开场剧情：点击屏幕任意处推进（打字中→跳过动画；否则→下一段；最后一段→关闭）
  el('story-overlay').addEventListener('click', storyClick);
  // 跳过全部对话：一键结束剧情直接开玩
  el('btn-skip-story').addEventListener('click', e => {
    e.stopPropagation();
    if (state.storyActive) endStory();
  });

  // 暂停营业（休息）：右上角按钮切换，遮罩点击恢复
  el('btn-pause').addEventListener('click', togglePause);
  el('pause-overlay').addEventListener('click', () => { if (state.paused) togglePause(); });

  // 设置：清空星币与声望存档
  el('btn-reset-save').addEventListener('click', () => {
    try { localStorage.removeItem(SAVE_KEY); } catch (e) {}
    state.coins = 0; state.rep = CONFIG.START_REP;
    state.runs = [];   // 个人排行榜一并清零
    renderHUD();
    toast('🗑 星币与声望已清零');
  });

  // 点选排队顾客查看需求（中间排队区）
  el('queue-line').addEventListener('click', e => {
    const n = e.target.closest('[data-cust]');
    if (n) selectCustomer(+n.dataset.cust);
  });

  // 设置：音效开关
  el('toggle-sound').addEventListener('change', () => {
    state.soundOn = el('toggle-sound').checked;
    toast(state.soundOn ? '🔊 音效已开启' : '音效已关闭');
  });
  el('toggle-bgm').addEventListener('change', () => {
    state.bgmOn = el('toggle-bgm').checked;
    toggleBGM();
  });

  initDragScroll();

  // 防缩放：iOS 手势缩放 / 双击缩放
  document.addEventListener('gesturestart', e => e.preventDefault());
  document.addEventListener('dblclick', e => e.preventDefault());
  // 首次点击：初始化音频（浏览器安全策略要求用户手势）
  document.addEventListener('pointerdown', onFirstTap);

  // 主循环启动（剧情播完前 tick 不推进游戏）
  setInterval(() => tick(0.1), 100);
  renderAll();

  // 开场剧情：播完自动解锁游戏并迎来第一位顾客
  // （调试入口：地址栏加 ?skipstory=1 可跳过剧情直接开玩）
  if (/[?&]skipstory=1/.test(location.search)) beginGame();
  else startStory();
}

init();

/* 等比缩放适配：固定设计稿 750×375，按可视区等比缩放居中；竖屏时整体旋转 90°（不弹提示，玩家自行转手机） */
function fitRoot() {
  const root = el('game-root');
  if (!root) return;
  const vw = window.innerWidth, vh = window.innerHeight;
  const portrait = vh > vw;   /* 宽高比判断方向（比 matchMedia 更稳） */
  const bw = 1150;   /* 固定设计基准：动态拉伸会破坏元素疏密，保持 1150×540 */
  let sc;
  if (portrait) sc = Math.min(vh / 1150, vw / 540);
  else sc = Math.min(vw / 1150, vh / 540);
  /* 精确像素居中：先算缩放后尺寸再算平移量（rotate 90° 时宽高互换），
     避免百分比 translate 与旋转组合的偏差导致画面整体偏左/偏上 */
  const w = bw * sc, h = 540 * sc;
  let tx, ty, rot = '';
  if (portrait) {
    /* 轻微不等比：横向 vw/540、纵向 vh/1150，两方向都精确铺满（差异约 2.6%，视觉无感） */
    const sx = vw / 540, sy = vh / 1150;
    root.style.transform = 'translate(' + vw.toFixed(2) + 'px, 0px) rotate(90deg) scale(' + sy.toFixed(4) + ', ' + sx.toFixed(4) + ')   /* 旋转后屏幕y=游戏x×scale_x → 纵向用 sy，横向用 sx */';
    const bgLayer2 = el('bg-layer');
    if (bgLayer2) bgLayer2.style.transform = 'none';   /* 背景保持原本横构图正立，不随游戏旋转 */
    window.__rotSign = 1;
    /* 滚动面板触控方向：旋转后游戏内纵向滚动对应屏幕横向手势 */
    const scrollersP = ['log-list', 'order-panel', 'shelf-grid', 'fruit-panel', 'settings-panel'];
    for (let i2 = 0; i2 < scrollersP.length; i2++) {
      const elmP = el(scrollersP[i2]);
      if (elmP) elmP.style.touchAction = 'pan-x';
    }
    return;
  } else {
    tx = vw - w;
    ty = 0;
  }
  root.style.transform = 'translate(' + tx.toFixed(2) + 'px, ' + ty.toFixed(2) + 'px)' + rot + ' scale(' + sc.toFixed(4) + ')';
  const bgLayer = el('bg-layer');
  if (bgLayer) bgLayer.style.transform = portrait ? 'rotate(90deg)' : 'none';   /* 背景层与游戏画面同方向 */
  /* 滚动面板触控方向：旋转后游戏内纵向滚动对应屏幕横向手势 */
  const scrollers = ['log-list', 'order-panel', 'shelf-grid', 'fruit-panel', 'settings-panel'];
  for (let i = 0; i < scrollers.length; i++) {
    const elm = el(scrollers[i]);
    if (elm) elm.style.touchAction = portrait ? 'pan-x' : 'pan-y';
  }
  window.__rotSign = portrait ? 1 : 0;   /* 旋转符号：拖拽/滚动按游戏内方向换算 */
}
window.addEventListener('resize', fitRoot);
window.addEventListener('orientationchange', fitRoot);
fitRoot();
/* 轮询兜底：容器标题栏伸缩等未派发 resize 的场景，每 600ms 校正一次 */
let lastVW = window.innerWidth, lastVH = window.innerHeight;
setInterval(function () {
  if (window.innerWidth !== lastVW || window.innerHeight !== lastVH) {
    lastVW = window.innerWidth; lastVH = window.innerHeight;
    fitRoot();
  }
}, 600);

/* Chrome 61 flex gap 行为检测（css-compatibility 规范） */
(function () {
  function supportsFlexGap() {
    var flex = document.createElement('div');
    flex.style.position = 'absolute';
    flex.style.visibility = 'hidden';
    flex.style.display = 'flex';
    flex.style.flexDirection = 'column';
    flex.style.rowGap = '1px';
    flex.appendChild(document.createElement('div'));
    flex.appendChild(document.createElement('div'));
    document.body.appendChild(flex);
    var supported = flex.scrollHeight === 1;
    flex.parentNode.removeChild(flex);
    return supported;
  }
  if (!supportsFlexGap()) document.documentElement.classList.add('no-flex-gap');
})();
